# Grazioso Salvare Dashboard Project

**Developer**: Name 
**Client**: Grazioso Salvare  
**Company**: Global Rain  

---

## Overview
A dashboard app that assists Grazioso Salvare in identifying and classifying dogs for search-and-rescue training based on shelter data from Austin, TX. Developed with MongoDB, Python, and Dash.

The app has complete CRUD (Create, Read, Update, Delete) functionality and filters data dynamically by rescue type, breed, age, and sex. It offers a transparent view of animal availability through visual dashboards and maps.

---

## Features
- Accessing MongoDB through a safe Python interface
- CRUD operations (create, read, update, delete) on animal records
- Filtering dogs based on rescue type (Water, Mountain/Wilderness, Disaster/Tracking)
- Filtering by age (less than 2 years), breed, and sex
- Filtering by animal type and outcome type
- Interactive data table that reacts to filters
- Breed distribution pie chart
- Geolocation map showing animal locations
- Human-readable console outputs for CRUD operations

---

## Tools Used
- **MongoDB**: Flexible schema, good for JSON-style documents
- **Python**: For server-side logic and modular development
- **Dash**: For building interactive dashboard UI
- **Dash Leaflet**: For real-time geolocation mapping
- **Pandas** and **Plotly Express**: For data handling and visualization

---

## Why MongoDB?
- Schema flexibility for shelter data
- Fast retrieval using dictionary-style queries
- Easily integrates with Python via `pymongo`
- Ideal for managing semi-structured documents

---

## Why Dash?
- Lightweight, reactive frontend built in Python
- MVC compatibility for clean separation of concerns
- Easy integration with Jupyter and deployment platforms

---

## How to Run
1. Ensure MongoDB is running on `localhost:27017`
2. Insert the altered Austin Animal Center CSV into the `animal_shelter.animals` collection
3. Execute the CRUD Python script to test DB functionality (create, read, update, delete)
4. Open and execute `ProjectTwoDashboard.ipynb` in JupyterLab or Jupyter Notebook
5. Utilize the dashboard filters and widgets to interactively view data
---

## Steps Completed

- Created CRUD Python module for MongoDB
- Developed filters for Water Rescue, Mountain/Wilderness Rescue, Disaster/Tracking
- Included further filters: by type of animal (dog/cat), sex, type of outcome, and breed
- Combined filtering options with database queries via Dash callbacks
- Connected filter input to data table, pie chart, and map view
- Made filtering logic include:
- Only dogs under 2 years old (≤ 104 weeks)
- Specific breeds translated to types of rescue
- Sex-based filtering
- Outcome type e.g. "Adoption" or "Return to Owner"
- Provided additional real-time feedback with Leaflet and Plotly Express charts
- Added developer ID and Grazioso Salvare branding in UI
---

## Additional Filters and Functionality Added

- **Breed-specific filtering** based on rescue type
- **Age restriction**: removes dogs aged over 2 years (utilizing `age_upon_outcome_in_weeks`)
- **Sex filtering**: males/females filtered on the basis of rescue requirements
- **Type of outcome filtering**: displaying dogs adoptable or retrievable
- **Animal filter type (dog, cat)** to enable adding the application functionality
- **Multi-type of queries**: `$and`, `$in`, `$set`, `$or` to enable compound filters
- **Dynamic response** to reset and all types of filters
- **Explain console logs** displaying success/failure while create, update, delete
- **Input validation** to block invalid or zero-length inserts
---

## Issues

- **MongoDB connection error**: Solved by confirming URI and managing exceptions
- **Absent leaflet markers**: Resolved by verifying lat/long field existence
- **Supporting dynamic updates**: Utilized Dash callbacks to update widgets
- **Making the application intuitive**: Maintained layout minimalistic with easy-to-read filter choices and comments
-----

## Screenshots (Required)

Included the following in submission:
- Dashboard default view (all animals displayed)
- View after applying **Water Rescue** filter
- View after applying **Mountain or Wilderness Rescue** filter
- View after applying **Disaster/Tracking** filter
- View after using the **Reset** option (all data displayed again)
---

## Resources
- [Dash by Plotly](https://dash.plotly.com/)
- [MongoDB Documentation](https://www.mongodb.com/docs/)
- [Dash Leaflet](https://dash-leaflet.herokuapp.com/)
- [Pandas Documentation](https://pandas.pydata.org/)
- [CS-340 Dashboard Specifications Document]
- [Austin Animal Center Outcomes Dataset (Modified CSV)]

---


**End of README**

